struct books{
    int id;
    char bookName[50];
    char authorName[50];
    char date[12];
};

struct student{
    int id;
    char sName[50];
    char sClass[50];
    int sRoll;
    char bookName[50];
    char date[12];
};



