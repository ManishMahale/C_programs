struct struAddBook
{
    int bookId;
    char bookname[90];
    char authorName[90];
    int bookQuantity;
    int bookPrice;
    int bookCount;
    int bookRackno;
};
