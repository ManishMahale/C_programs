struct struID
{
    int id;
};